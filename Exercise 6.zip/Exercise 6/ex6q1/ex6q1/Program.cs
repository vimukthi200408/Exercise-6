﻿namespace ex5q1
{
    class Program
    {


        static void Main(string[] args)
        {
            int[,] array = { { 65, 78, 69, 55, 74 }, { 45, 85, 78, 64, 91 }, { 56, 84, 67, 58, 89 }, { 85, 65, 95, 74, 99 }, { 98, 78, 85, 84, 98 }, { 65, 45, 81, 52, 83 } };


            int total;
            int totMath = 0, totScience = 0, totEnglish = 0, totICT = 0, totReligion = 0;


            for (int i = 0; i < array.GetLength(0); i++)
            {
                totMath = totMath + array[i, 0];
                totScience = totScience + array[i, 1];
                totEnglish = totEnglish + array[i, 2];
                totICT = totICT + array[i, 3];
                totReligion = totReligion + array[i, 4];


            }
            Console.WriteLine("Part A : \n");
            Console.WriteLine("Average mark for Math : " + totMath / 6);
            Console.WriteLine("Average mark for Science : " + totScience / 6);
            Console.WriteLine("Average mark for English : " + totEnglish / 6);
            Console.WriteLine("Average mark for ICT : " + totICT / 6);
            Console.WriteLine("Average mark for Religion : " + totReligion / 6);


            Console.WriteLine("Part B : \n");
            for (int i = 0; i < array.GetLength(0); i++)
            {
                total = 0;
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    total = total + array[i, j];

                }
                Console.WriteLine(" for student numner : " + (i + 1) + " the average is  : " + total / 5);
            }

            Console.WriteLine("Part C : \n");
            int max = int.MinValue;
            for (int i = 0; i < array.GetLength(1); i++)
            {
                max = int.MinValue;
                for (int j = 0; j < array.GetLength(0); j++)
                {
                    if (array[j, i] > max)
                    {
                        max = array[j, i];
                    }
                }
                Console.WriteLine(" subject number : " + (i + 1) + " the maximum number is " + max);
            }

            Console.WriteLine("Part D : \n");
            int min = int.MaxValue;
            for (int i = 0; i < array.GetLength(1); i++)
            {
                min = int.MaxValue;
                for (int j = 0; j < array.GetLength(0); j++)
                {
                    if (array[j, i] < min)
                    {
                        min = array[j, i];
                    }
                }
                Console.WriteLine(" subject number : " + (i + 1) + " the minimum mark is " + min);
            }

            Console.WriteLine("Part E : \n");
            int maxstudent = int.MinValue;
            for (int i = 0; i < array.GetLength(0); i++)
            {
                maxstudent = int.MinValue;
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    if (array[i, j] > maxstudent)
                    {
                        maxstudent = array[i, j];
                    }
                }

                Console.WriteLine("student id number : " + (i + 1) + " the maximum mark is " + maxstudent);

            }

            Console.WriteLine("Part F : \n");

            int minstudent = int.MaxValue;
            for (int i = 0; i < array.GetLength(0); i++)
            {
                minstudent = int.MaxValue;


                for (int j = 0; j < array.GetLength(1); j++)
                {
                    if (array[i, j] < minstudent)
                    {
                        minstudent = array[i, j];
                    }
                }

                Console.WriteLine("student id number :  " + (i + 1) + " the minimum mark is " + minstudent);
            }



        }


        
    }
}