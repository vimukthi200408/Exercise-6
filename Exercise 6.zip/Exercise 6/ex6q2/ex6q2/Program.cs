﻿class Program
{
    static void Main(string[] args)
    {
        int[] array = { 9,8,7,6,5 };
        int[] array2 = { 4,3,2,1 };
        int[] arraynew = new int[array.Length + array2.Length];

        
       
        int count=0;
            for (int j=0;j < array.Length;j++)
            {
                arraynew[j] = array[j];
            count = j;
            }
            
            for (int k = 0; k <array2.Length; k++)
            {
            count++;
            arraynew[count] = array2[k];
            
            }
     

        Array.Sort(arraynew);

        for (int i = 0;i<arraynew.Length; i++)
        {
            Console.WriteLine(arraynew[i]);
        }

    }
}