﻿class Program
{
    static void Main(string[] args)
    {
        int num1, num2, num3, num4;

        Console.Write("Entet number 1 : ");
        num1=Convert.ToInt32(Console.ReadLine());
        Console.Write("Entet number 2 : ");
        num2 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Entet number 3 : ");
        num3 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Entet number 4 : ");
        num4 = Convert.ToInt32(Console.ReadLine());

        if ((num1 == num2) && (num3 == num4))
        {

            Console.WriteLine("All are equal");
        }
        else
        {
            Console.WriteLine("Not equal");
        }
        
   
    }
}