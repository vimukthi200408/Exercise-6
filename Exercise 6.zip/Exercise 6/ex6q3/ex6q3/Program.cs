﻿class Program
{
    static void Main(string[] args)
    {

        int[] array = { 12,34,54,2,6,745,346,86,45,78,6, 20 ,20,20};
        int count =0;
        bool found = false, foundbefore = false, foundafter=false;


        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] == 20)
            {
                count++;

                if (count == 3)
                {
                    found = true;

                    if (array[i - 1] == 20)
                    {
                        foundbefore = true;
                    }
                    if (array[i - 2] == 20)
                    {
                        foundafter = true;
                    }

                    if ((foundafter == true) && (foundbefore == true))
                    {
                        Console.WriteLine("Three 20's found together");
                        
                    }
                    else
                    {
                        Console.WriteLine("TThree 20's NOT found together");
                       
                    }

                   
                }
            }
        }

        if (found == false)
        {
            Console.WriteLine("Not found");
        }

    }

}
