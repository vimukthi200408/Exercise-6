﻿class Program
{
    static void Main(string[] args)
    {
        int[] array = { 1, 2, 3, 4, 4, 56, 6 };
        int[] newarray = new int[10];
    
        int option,num;

        
        Console.WriteLine("Press 1 :  Accept elements of an array of 10");
        Console.WriteLine("Press 2 :  Display elements of an array");
        Console.WriteLine("Press 3 :  Search the element within array given by user");
        Console.WriteLine("Press 4 :  Sort the array using bubble sort method");
        Console.WriteLine("Enter option : ");

        option = Convert.ToInt32(Console.ReadLine());

        switch (option)
        {
            case 1:

                Console.WriteLine("Enter 10 numbers : ");
                for (int i =0;i<newarray.Length;i++)
                {
                    newarray[i]=Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("Array created:  ");
                display(newarray);

                break;
            case 2:
                display(array);
                break;
            case 3:
                Console.WriteLine("Enter a number to seaech : ");
                num = Convert.ToInt32(Console.ReadLine());
                search(array, num);
                break;
            case 4:

                //bubble sort
                break;
            default:
                Console.WriteLine("error");
                break;

        }

    }

    static void search(int[] array, int num)
    {
        bool found = false;
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] == num)
            {
                found = true;
                break;
            }
            else
            {
                found = false;
                
            }

        }
        if (found == true)
        {
            Console.WriteLine("Found");
        } else
        {
            Console.WriteLine("Not found");
        }
    }

    static void display(int[] array)
    {
        for (int i = 0; i < array.Length; i++)
        {
            Console.Write(array[i]+" ");
        }
    }
}