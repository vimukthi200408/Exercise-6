﻿class Program
{
    static void Main(string[] args)
    {
        Console.Write("\n Part A : ");
        Console.WriteLine((101 + 4) / 3 * 5);
        Console.Write("\n Part B : ");
        Console.WriteLine(true && true);
        Console.Write("\n Part C : ");
        Console.WriteLine(false && true);
        Console.Write("\n Part D : ");
        Console.WriteLine((false && false) || (true && true));
        Console.Write("\n Part E : ");
        Console.WriteLine((false || false) && (true && true));
    }
}