﻿class Program
{
    static void Main(string[] args)
    {
        int num;

        Console.Write("Enter the number id rows : ");
        num = Convert.ToInt32(Console.ReadLine());

        int outputnum = 0 ;

        for (int i = 0; i < num; i++)
        {
            for (int j = 1; j < i + 1; j++)
            {
                Console.Write(outputnum++ +" ");
            }
            Console.WriteLine(" ");
        }
       
    }
}