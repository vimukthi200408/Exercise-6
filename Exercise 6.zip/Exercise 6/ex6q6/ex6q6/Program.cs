﻿class Program
{
    static void Main(string[] args)
    {

        int[] array = {1,0,2,0,3,4,5,6,7,8,9};

        for (int i = 0;i<array.Length;i++)
        {
            if (array[i] == 0)
            {
                array[]

            }
                    
        }

    }

}